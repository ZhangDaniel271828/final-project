
import view.MainView;

public class App {
    public static void main(String[] args) {
        // 启动应用程序
        javax.swing.SwingUtilities.invokeLater(() -> new MainView());
    }
}